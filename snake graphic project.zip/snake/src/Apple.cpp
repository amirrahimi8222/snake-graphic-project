//
// Created by HAMAHANG on 6/30/2022.
//

#include "Apple.h"
Apple::Apple() {
    //setting the first position off apple
    Vector2f startingPosition(400, 300);
    // changing the apple place
    sprite.setSize(Vector2f(20,20));
    sprite.setFillColor(Color::Red);
    sprite.setPosition(startingPosition);
}
// changing the apple place
void Apple::setPosition(Vector2f newPosition) {
    sprite.setPosition(newPosition);
}

RectangleShape Apple::getSprite() {
    return sprite;
}