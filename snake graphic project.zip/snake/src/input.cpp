#include "Engine.h"
void Engine::input() {
    Event event{};

    while (window.pollEvent(event)) {
        // Window closed(the file will run until window is open so we have to define a function to close the window)
        if (event.type == Event::Closed) {
            window.close();
        }

        // Handle Keyboard Input
        //here i write a condition for any key press..
        if (event.type == Event::KeyPressed) {
            //escaping from the game and stop running
            // Quit
            if (Keyboard::isKeyPressed(Keyboard::Escape)) {
                window.close();
            }
            //pause
            if (Keyboard::isKeyPressed(Keyboard::P)){
                togglePause();
            }
            if (Keyboard::isKeyPressed(Keyboard::L)){
                beginNextLevel();
            }


            if (currentGameState==GameState::GAMEOVER) {
                if (Keyboard::isKeyPressed(Keyboard::Enter)) {
                    startTheGame();
                }
            }


        }
    } // END while pollEvent
    // Directions
    if (Keyboard::isKeyPressed(Keyboard::Up)) {
        addDirection(Direction::UP);
    }
    else if (Keyboard::isKeyPressed(Keyboard::Down)) {
        addDirection(Direction::DOWN);
    }
    else if (Keyboard::isKeyPressed(Keyboard::Left)) {
        addDirection(Direction::LEFT);
    }
    else if (Keyboard::isKeyPressed(Keyboard::Right)) {
        addDirection(Direction::RIGHT);
    }
}
// snake movement have some condition(not same direction , not right after that left ,....)
void Engine::addDirection(int newDirection) {
    if (directionQueue.empty()) {
        directionQueue.emplace_back(newDirection);
    }
    else {
        if (directionQueue.back() != newDirection) {
            directionQueue.emplace_back(newDirection);
        }
    }
}