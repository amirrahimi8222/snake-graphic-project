#include "Engine.h"
int main() {
    sf::Music music;

    if(!music.openFromFile("snakeMusic.ogg"))
        printf("not found");

    music.play();
    Engine engine;
    engine.run();
    return 0;
}
