#include "SnakeSection.h"
//here i make snakes color first position and Initial size
SnakeSection::SnakeSection(Vector2f startPosition) {
    section.setSize(Vector2f(20, 20));
    section.setFillColor(Color::Green);
    section.setPosition(startPosition);
    position = startPosition;
}

Vector2f SnakeSection::getPosition() {
    return position;
}
//passing new position to last position
void SnakeSection::setPosition(Vector2f newPosition) {
    position = newPosition;
}
//getting the shape of snake
RectangleShape SnakeSection::getShape() {
    return section;
}
//the movement of snake which we command in setPosition
void SnakeSection::update() {
    section.setPosition(position);
}

