#include "wall.h"
wall::wall(Vector2f position, Vector2f size) {
    wallShape.setSize(size);
    wallShape.setFillColor(Color::Yellow);
    wallShape.setPosition(position);
}
RectangleShape wall::getShape() {
    return wallShape;
}