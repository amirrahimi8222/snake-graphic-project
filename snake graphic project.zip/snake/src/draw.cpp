#include "Engine.h"
//defining draw function
void Engine::draw() {
    window.clear(Color::Black);
    //draw walls
    for (auto & w : wallSections) {
        window.draw(w.getShape());

    }
    // draw apple
    window.draw(apple.getSprite());
    // Draw snake sections
    for (auto & s : snake) {
        window.draw(s.getShape());
    }

    //draw text
    window.draw(titleText);
    window.draw(currentLevelText);
    window.draw(applesEatenText);
    window.draw( scoreText);
    // still i creat a window


    //draw game over
    if (currentGameState == GameState::GAMEOVER) {
        window.draw(gameOverText);
        window.draw(pressEnterText);
    }
        window.display();
}