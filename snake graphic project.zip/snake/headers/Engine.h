//
// Created by HAMAHANG on 6/25/2022.
//

#ifndef SNAKE_ENGINE_H
#define SNAKE_ENGINE_H
//here im going to add sfml graphics libraries.
#include <SFML/Graphics.hpp>

#include <SFML/Audio.hpp>
#include "SFML/Audio.hpp"
//here im using rectangle shape fore bord which snake move on it
#include <SFML/Graphics/RectangleShape.hpp>
// this library includes snakes sections
#include "SnakeSection.h"
//apple header
#include "Apple.h"
//wall header
#include "wall.h"
// That is, we can change the size of the vector during the execution of a program as per our requirements.
//here we treat to a snake like an array vector when eat something our dynamic array increase itself.
#include <vector>
//we can popping things off the front ,use it and throw it away
#include<deque>
#include <fstream>
// im using sf library to delete sf prefix to make code more readable (from sfml library)
using namespace sf;
//adding some c++ libraries{cout,cin,....}
using namespace std;

class Engine {
    // every thing we put in private section its not accessible in another files and keep them safe from outside
                                    private:

// window
Vector2f resolution;
RenderWindow window;
// creating a fps for the variable this is frames per second to limit how many frames per sec our window runs at
const unsigned int FPS=60;
static const Time TimePerFrame;
//making a snake from array
    vector<SnakeSection> snake;
    // leading snake and Specifying speed
    int snakeDirection;
    //evaluating direction with integer number
    deque<int>directionQueue;// queue for direction key pressed
    int speed;

    int sectionToAdd;//how many sections to Add to the snake by eating apple.
    //counting apple for calculating score
int applesEatenThisLevel;
int applesEatenTotal;
//score
unsigned long long int score;

    Apple apple;

    // we need a vector to hold wall section.
    vector<wall>wallSections;
    int currentLevel;
    int maxLevels;
    vector<String> levels;

    // doing font subjects
    Font mainFont;
    Text titleText;
    //doing text objects for apple
    Text applesEatenText;
    Text currentLevelText;
    // score text
    Text scoreText;
    Text gameOverText;
    Text pressEnterText;


    // the last time that snake move.
    Time timeSinceLastMove;
    // current game state show us the situation of the game-->game over continue ....
    int currentGameState;
    // we use last game state to help us on pause the game we need to know what the last state was
    int lastGameState;

                                    public:
    enum Direction{ UP , RIGHT , DOWN , LEFT };
    enum GameState{RUNNING,PAUSED,GAMEOVER};
    //here we need a constructor which is the same name as our class.
    Engine();

    void input();
   // function to draw stuff to the screen
   void addDirection(int newDirection);
   // now we have to make function to make snake move
   void update();

    void draw();
    //creating a function for property score game over and ...
    static void setupText(Text *textItem,const Font & font, const String &value,int size,Color color);
    void newSnake();
    void addSnakeSection();

    void moveApple();
    //check the levels and add them to the vector
    void checkLevelFiles();
    void loadLevel(int levelNumber);
    // the main loop will be in the run function
    void beginNextLevel();
    void startTheGame();
    void togglePause();
    void run();

};


#endif //SNAKE_ENGINE_H
