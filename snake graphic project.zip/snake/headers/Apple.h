#ifndef UPDATE_CPP_APPLE_H
#define UPDATE_CPP_APPLE_H

#include <SFML/Graphics.hpp>
using namespace sf;
//for apple we are not creating new apple we change the place of apple it seems we have new apple
class Apple {
private:
    // we use sprites to make another shapes. not easy shape such as rectangle or square.
    //for sprites first, we load in a texture, then we create a sprite and pass in the texture.
    RectangleShape sprite;
public:
    //constructor
    Apple();
//apples position
    void setPosition(Vector2f newPosition);
    RectangleShape getSprite();

};


#endif //UPDATE_CPP_APPLE_H
