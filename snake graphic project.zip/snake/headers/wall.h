#ifndef UPDATE_CPP_WALL_H
#define UPDATE_CPP_WALL_H
#include <SFML/Graphics.hpp>

using namespace sf;
class wall {
private:
    RectangleShape wallShape;
public:
    wall(Vector2f position ,Vector2f size);

    RectangleShape getShape();

};


#endif //UPDATE_CPP_WALL_H
